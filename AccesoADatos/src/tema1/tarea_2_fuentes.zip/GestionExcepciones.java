package tema1;

public class GestionExcepciones extends Exception {
	public GestionExcepciones(String mensaje) {
		super(mensaje);
	}
}
